<?php
namespace Mirakl\MMP\Shop\Domain\Order\Tax;

use Mirakl\MMP\FrontShop\Domain\Order\Tax\AbstractOrderTax;

class OrderTax extends AbstractOrderTax
{}