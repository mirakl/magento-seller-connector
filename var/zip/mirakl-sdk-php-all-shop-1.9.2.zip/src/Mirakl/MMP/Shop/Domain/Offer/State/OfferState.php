<?php
namespace Mirakl\MMP\Shop\Domain\Offer\State;

use Mirakl\MMP\Common\Domain\Offer\State\AbstractOfferState;

/**
 * Describe the offer condition
 * Example: New, Used...
 */
class OfferState extends AbstractOfferState
{}