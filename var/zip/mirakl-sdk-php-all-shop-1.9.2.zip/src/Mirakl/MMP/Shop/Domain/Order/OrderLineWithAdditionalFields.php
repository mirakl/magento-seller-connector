<?php
namespace Mirakl\MMP\Shop\Domain\Order;

use Mirakl\MMP\Common\Domain\Order\AbstractOrderLineWithAdditionalFields;

class OrderLineWithAdditionalFields extends AbstractOrderLineWithAdditionalFields
{}