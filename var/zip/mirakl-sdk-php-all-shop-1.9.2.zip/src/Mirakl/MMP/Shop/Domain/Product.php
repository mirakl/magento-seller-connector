<?php
namespace Mirakl\MMP\Shop\Domain;

use Mirakl\MMP\Common\Domain\Product\AbstractProduct;

class Product extends AbstractProduct
{}