<?php
namespace Mirakl\MCI\Common\Domain\Product;

use Mirakl\Core\Domain\MiraklObject;

/**
 * @method  string  getImportId()
 * @method  $this   setImportId(string $importId)
 */
class ProductImportTracking extends MiraklObject
{}