<?php
namespace Mirakl\MMP\Common\Domain\Adjust;

use Mirakl\MMP\Common\Domain\Error;

class AdjustmentError extends Error
{}