<?php
namespace Mirakl\MMP\Common\Domain\Shipping;

/**
 * @method  string  getDescription()
 * @method  $this   setDescription(string $description)
 */
class ShippingTypeWithDescription extends ShippingType
{}