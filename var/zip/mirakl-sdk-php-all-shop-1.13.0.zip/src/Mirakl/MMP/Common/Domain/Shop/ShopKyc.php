<?php
namespace Mirakl\MMP\Common\Domain\Shop;

use Mirakl\Core\Domain\MiraklObject;

/**
 * @method  string  getReason()
 * @method  $this   setReason(string $reason)
 * @method  string  getStatus()
 * @method  $this   setStatus(string $status)
 */
class ShopKyc extends MiraklObject
{}