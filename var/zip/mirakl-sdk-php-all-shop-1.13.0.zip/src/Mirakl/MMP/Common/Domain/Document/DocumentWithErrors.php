<?php
namespace Mirakl\MMP\Common\Domain\Document;

use Mirakl\MMP\Common\Domain\InputWithErrors;

class DocumentWithErrors extends InputWithErrors
{}