<?php
namespace Mirakl\MMP\Common\Domain\Shop;

class ShopDomain
{
    const PRODUCT = 'PRODUCT';
    const SERVICE = 'SERVICE';
}