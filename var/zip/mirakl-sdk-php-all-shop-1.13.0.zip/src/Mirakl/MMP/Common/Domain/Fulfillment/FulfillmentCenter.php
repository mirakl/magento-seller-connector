<?php
namespace Mirakl\MMP\Common\Domain\Fulfillment;

use Mirakl\Core\Domain\MiraklObject;

/**
 * @method  string  getCode()
 * @method  $this   setCode(string $code)
 */
class FulfillmentCenter extends MiraklObject
{}