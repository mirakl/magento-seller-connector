<?php
namespace Mirakl\MMP\OperatorShop\Domain\Offer\Importer;

use Mirakl\Core\Domain\MiraklObject;

/**
 * @method  int     getImportId()
 * @method  $this   setImportId(int $id)
 */
class OfferImportTracking extends MiraklObject
{}