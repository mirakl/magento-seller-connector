<?php
namespace Mirakl\MMP\OperatorShop\Domain\Offer\Importer;

/**
 * @method  string  getProductImportId()
 * @method  $this   setProductImportId(string $productImportId)
 */
class OfferProductImportTracking extends OfferImportTracking
{}