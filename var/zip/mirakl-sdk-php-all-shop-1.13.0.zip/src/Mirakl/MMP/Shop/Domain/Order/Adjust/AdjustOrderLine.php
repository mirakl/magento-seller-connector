<?php
namespace Mirakl\MMP\Shop\Domain\Order\Adjust;

use Mirakl\MMP\Common\Domain\Adjust\AbstractAdjustOrderLine;

class AdjustOrderLine extends AbstractAdjustOrderLine
{}