<?php
namespace Mirakl\MMP\Shop\Domain\Order\Cancelation;

use Mirakl\MMP\Common\Domain\Order\Cancelation\AbstractCreateCancelation;

class CreateCancelation extends AbstractCreateCancelation
{}
