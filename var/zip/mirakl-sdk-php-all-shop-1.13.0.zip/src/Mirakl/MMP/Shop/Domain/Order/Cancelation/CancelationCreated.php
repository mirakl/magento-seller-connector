<?php
namespace Mirakl\MMP\Shop\Domain\Order\Cancelation;

use Mirakl\MMP\Common\Domain\Order\Cancelation\AbstractCancelationCreated;

class CancelationCreated extends AbstractCancelationCreated
{}
