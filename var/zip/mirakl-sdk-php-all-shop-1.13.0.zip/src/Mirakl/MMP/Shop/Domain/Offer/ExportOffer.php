<?php
namespace Mirakl\MMP\Shop\Domain\Offer;

use Mirakl\MMP\Common\Domain\Offer\AbstractExportOffer;

class ExportOffer extends AbstractExportOffer
{}
