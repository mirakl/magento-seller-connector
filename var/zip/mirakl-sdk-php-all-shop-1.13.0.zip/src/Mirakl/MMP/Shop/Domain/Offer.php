<?php
namespace Mirakl\MMP\Shop\Domain;

use Mirakl\MMP\Common\Domain\Offer\AbstractOfferWithShopInfo;

class Offer extends AbstractOfferWithShopInfo
{}