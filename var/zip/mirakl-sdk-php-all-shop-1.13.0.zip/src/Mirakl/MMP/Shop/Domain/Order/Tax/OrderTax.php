<?php
namespace Mirakl\MMP\Shop\Domain\Order\Tax;

use Mirakl\MMP\Common\Domain\Order\Tax\AbstractOrderTax;

class OrderTax extends AbstractOrderTax
{}