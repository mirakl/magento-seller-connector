<?php
namespace Mirakl\MMP\Shop\Domain\Shop;

use Mirakl\MMP\Common\Domain\Shop\AbstractPaymentDetails;

class ShopPaymentDetails extends AbstractPaymentDetails
{}