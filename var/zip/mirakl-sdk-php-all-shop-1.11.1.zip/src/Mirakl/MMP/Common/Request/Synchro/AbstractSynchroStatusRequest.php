<?php
namespace Mirakl\MMP\Common\Request\Synchro;

use Mirakl\Core\Request\AbstractSynchroRequest;

abstract class AbstractSynchroStatusRequest extends AbstractSynchroRequest
{}