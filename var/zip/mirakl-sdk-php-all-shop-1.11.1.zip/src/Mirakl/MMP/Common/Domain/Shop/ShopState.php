<?php
namespace Mirakl\MMP\Common\Domain\Shop;

class ShopState
{
    const OPEN      = 'OPEN';
    const CLOSE     = 'CLOSE';
    const SUSPENDED = 'SUSPENDED';
}