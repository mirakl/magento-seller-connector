<?php
namespace Mirakl\MMP\Common\Domain\Message;

use Mirakl\Core\Domain\MiraklObject;

/**
 * @method  string  getId()
 * @method  $this   setId(string $id)
 */
class MessageCreated extends MiraklObject
{}