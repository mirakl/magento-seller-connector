<?php
namespace Mirakl\MMP\OperatorShop\Domain\Offer\Importer;

use Mirakl\Core\Domain\MiraklObject;

/**
 * @method  string  getImportId()
 * @method  $this   setImportId(string $id)
 */
class OfferImportTracking extends MiraklObject
{}