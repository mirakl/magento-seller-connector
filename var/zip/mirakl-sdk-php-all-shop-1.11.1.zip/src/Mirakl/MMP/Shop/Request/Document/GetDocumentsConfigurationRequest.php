<?php
namespace Mirakl\MMP\Shop\Request\Document;

use Mirakl\MMP\Common\Request\Document\AbstractGetDocumentsConfigurationRequest;

/**
 * Class GetDocumentsConfigurationRequest
 * @package Mirakl\MMP\Shop\Request\Document
 */
class GetDocumentsConfigurationRequest extends AbstractGetDocumentsConfigurationRequest
{}